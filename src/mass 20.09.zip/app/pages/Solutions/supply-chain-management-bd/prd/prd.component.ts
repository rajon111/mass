import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prd',
  templateUrl: './prd.component.html',
  styleUrls: ['./prd.component.css']
})
export class PrdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
