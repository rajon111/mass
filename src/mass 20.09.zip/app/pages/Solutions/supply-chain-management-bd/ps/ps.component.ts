import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ps',
  templateUrl: './ps.component.html',
  styleUrls: ['./ps.component.css']
})
export class PsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
