import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hcm',
  templateUrl: './hcm.component.html',
  styleUrls: ['./hcm.component.css']
})
export class HcmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
