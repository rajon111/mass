import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supply-chain-management-bd',
  templateUrl: './supply-chain-management-bd.component.html',
  styleUrls: ['./supply-chain-management-bd.component.css']
})
export class SupplyChainManagementBdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
