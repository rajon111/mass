import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-csc',
  templateUrl: './csc.component.html',
  styleUrls: ['./csc.component.css']
})
export class CscComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
