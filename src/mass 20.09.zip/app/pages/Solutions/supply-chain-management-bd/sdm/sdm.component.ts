import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sdm',
  templateUrl: './sdm.component.html',
  styleUrls: ['./sdm.component.css']
})
export class SdmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
