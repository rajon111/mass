import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-and-distribution-management',
  templateUrl: './sales-and-distribution-management.component.html',
  styleUrls: ['./sales-and-distribution-management.component.css']
})
export class SalesAndDistributionManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
