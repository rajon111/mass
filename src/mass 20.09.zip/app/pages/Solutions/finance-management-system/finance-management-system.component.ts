import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-finance-management-system',
  templateUrl: './finance-management-system.component.html',
  styleUrls: ['./finance-management-system.component.css']
})
export class FinanceManagementSystemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
